# JavaProject_findKHU

#Android <-> NodeJS <-> MySQL

#Server code 실행법
-npm install
-node app.js
-localhost:8000/
